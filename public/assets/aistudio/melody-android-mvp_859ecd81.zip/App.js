import React, { useMemo, useState } from "react";
import {
  ActivityIndicator, Image, SafeAreaView, ScrollView, StatusBar,
  StyleSheet, Text, TextInput, TouchableOpacity, View
} from "react-native";
import { WebView } from "react-native-webview";

const C = {
  bg: "#0B0B10", panel: "#15151D", panel2: "#1D1D28",
  text: "#F6F4FA", muted: "#9292A2", lime: "#C7F36B",
  purple: "#9B83FF", line: "#292936"
};

const seed = [
  { id: "jfKfPfyJRdk", title: "Night Changes", artist: "One Direction", art: "https://i.ytimg.com/vi/jfKfPfyJRdk/hqdefault.jpg" },
  { id: "k4V3Mo61fJM", title: "Perfect", artist: "Ed Sheeran", art: "https://i.ytimg.com/vi/2Vv-BfVoq4g/hqdefault.jpg" },
  { id: "JGwWNGJdvx8", title: "Shape of You", artist: "Ed Sheeran", art: "https://i.ytimg.com/vi/JGwWNGJdvx8/hqdefault.jpg" },
  { id: "RgKAFK5djSk", title: "See You Again", artist: "Wiz Khalifa", art: "https://i.ytimg.com/vi/RgKAFK5djSk/hqdefault.jpg" }
];

function Chip({ label, active, onPress }) {
  return <TouchableOpacity onPress={onPress} style={[s.chip, active && s.chipOn]}>
    <Text style={[s.chipText, active && { color: C.bg }]}>{label}</Text>
  </TouchableOpacity>;
}

function SongRow({ song, onPress, onLike, liked }) {
  return <TouchableOpacity style={s.songRow} onPress={onPress}>
    <Image source={{ uri: song.art || `https://i.ytimg.com/vi/${song.id}/hqdefault.jpg` }} style={s.songArt}/>
    <View style={{ flex: 1 }}>
      <Text numberOfLines={1} style={s.songTitle}>{song.title}</Text>
      <Text numberOfLines={1} style={s.songArtist}>{song.artist || "YouTube music"}</Text>
    </View>
    <TouchableOpacity onPress={onLike} style={s.likeBtn}><Text style={{ color: liked ? C.lime : C.muted, fontSize: 20 }}>{liked ? "♥" : "♡"}</Text></TouchableOpacity>
    <Text style={{ color: C.muted, fontSize: 20 }}>⋯</Text>
  </TouchableOpacity>;
}

export default function App() {
  const [tab, setTab] = useState("Home");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [current, setCurrent] = useState(seed[0]);
  const [playing, setPlaying] = useState(false);
  const [liked, setLiked] = useState([]);
  const [queue, setQueue] = useState(seed);
  const apiKey = process.env.EXPO_PUBLIC_YOUTUBE_API_KEY;

  const toggleLike = (song) => setLiked(old =>
    old.some(x => x.id === song.id) ? old.filter(x => x.id !== song.id) : [song, ...old]
  );
  const play = (song) => {
    setCurrent(song);
    setPlaying(true);
    setQueue(old => [song, ...old.filter(x => x.id !== song.id)]);
  };
  const search = async () => {
    if (!query.trim()) return;
    if (!apiKey) {
      setError("Add your YouTube Data API key to .env to enable live search.");
      setResults([]);
      return;
    }
    setLoading(true); setError("");
    try {
      const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoCategoryId=10&maxResults=15&q=${encodeURIComponent(query)}&key=${apiKey}`;
      const response = await fetch(url);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error?.message || "Search failed");
      setResults((data.items || []).map(item => ({
        id: item.id.videoId,
        title: item.snippet.title,
        artist: item.snippet.channelTitle,
        art: item.snippet.thumbnails?.medium?.url || `https://i.ytimg.com/vi/${item.id.videoId}/hqdefault.jpg`
      })));
    } catch (e) { setError(e.message || "Could not search YouTube."); }
    finally { setLoading(false); }
  };

  const list = tab === "Library" ? liked : (tab === "Search" && results.length ? results : seed);
  const title = tab === "Home" ? "Good evening" : tab === "Search" ? "Find your sound" : "Your collection";

  return <SafeAreaView style={s.safe}>
    <StatusBar barStyle="light-content" backgroundColor={C.bg}/>
    <View style={s.header}>
      <View style={s.brandMark}><Text style={{ color: C.bg, fontWeight: "900", fontSize: 18 }}>M</Text></View>
      <Text style={s.brand}>melody</Text>
      <View style={{ flex: 1 }}/>
      <TouchableOpacity style={s.avatar}><Text style={{ color: C.text, fontWeight: "700" }}>Y</Text></TouchableOpacity>
    </View>

    <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
      <Text style={s.eyebrow}>YOUR SOUNDTRACK, YOUR RULES</Text>
      <Text style={s.heading}>{title}</Text>
      {tab === "Home" && <>
        <View style={s.hero}>
          <View style={{ flex: 1 }}>
            <Text style={s.heroTag}>MADE FOR YOUR MOMENT</Text>
            <Text style={s.heroTitle}>Tune in.{`\n`}Zone out.</Text>
            <Text style={s.heroSub}>A little more you in every beat.</Text>
            <TouchableOpacity style={s.heroButton} onPress={() => play(seed[0])}>
              <Text style={s.heroButtonText}>▶  PLAY MIX</Text>
            </TouchableOpacity>
          </View>
          <View style={s.orb}><Text style={{ fontSize: 50 }}>♫</Text></View>
        </View>
        <Text style={s.sectionTitle}>Quick picks</Text>
      </>}
      {tab === "Search" && <View style={s.searchBox}>
        <Text style={{ fontSize: 18, color: C.muted }}>⌕</Text>
        <TextInput value={query} onChangeText={setQuery} onSubmitEditing={search}
          placeholder="Songs, artists, moods..." placeholderTextColor={C.muted}
          style={s.searchInput} returnKeyType="search"/>
        <TouchableOpacity onPress={search}><Text style={{ color: C.lime, fontWeight: "800" }}>GO</Text></TouchableOpacity>
      </View>}
      {tab === "Search" && <View style={s.chips}>
        {["Trending", "Punjabi", "Chill", "Workout"].map(x => <Chip key={x} label={x} active={false} onPress={() => { setQuery(x); }}/>)}
      </View>}
      {tab === "Library" && <Text style={s.subheading}>Liked songs · {liked.length} tracks</Text>}
      {tab !== "Home" && tab !== "Library" && null}
      {loading && <ActivityIndicator color={C.lime} style={{ margin: 20 }}/>}
      {!!error && <Text style={s.error}>{error}</Text>}
      {tab === "Home" && <View style={s.featureCard}>
        <Image source={{ uri: "https://i.ytimg.com/vi/JGwWNGJdvx8/hqdefault.jpg" }} style={s.featureArt}/>
        <View style={{ flex: 1 }}>
          <Text style={s.featureLabel}>DAILY ROTATION</Text>
          <Text style={s.featureTitle}>The familiar hits</Text>
          <Text style={s.songArtist}>Songs you can sing by heart</Text>
        </View>
        <TouchableOpacity onPress={() => play(seed[2])}><Text style={{ color: C.lime, fontSize: 24 }}>▶</Text></TouchableOpacity>
      </View>}
      <View style={s.sectionHeader}>
        <Text style={s.sectionTitle}>{tab === "Search" && results.length ? "Search results" : tab === "Library" ? "Liked tracks" : "Popular right now"}</Text>
        {tab === "Home" && <Text style={s.seeAll}>SEE ALL</Text>}
      </View>
      {list.length === 0 && tab === "Library" ? <View style={s.empty}><Text style={{ fontSize: 34 }}>♡</Text><Text style={s.emptyTitle}>Your favourites live here</Text><Text style={s.songArtist}>Tap the heart on any track to save it.</Text></View> :
        list.map(song => <SongRow key={song.id} song={song} onPress={() => play(song)}
          liked={liked.some(x => x.id === song.id)} onLike={() => toggleLike(song)}/>)}
      <Text style={s.footer}>DISCOVER MORE. FEEL MORE.</Text>
    </ScrollView>

    {current && <View style={s.player}>
      <Image source={{ uri: current.art || `https://i.ytimg.com/vi/${current.id}/hqdefault.jpg` }} style={s.playerArt}/>
      <View style={{ flex: 1 }}>
        <Text numberOfLines={1} style={s.playerTitle}>{current.title}</Text>
        <Text numberOfLines={1} style={s.playerArtist}>{current.artist}</Text>
      </View>
      <TouchableOpacity onPress={() => toggleLike(current)}><Text style={{ color: liked.some(x => x.id === current.id) ? C.lime : C.text, fontSize: 22 }}>♡</Text></TouchableOpacity>
      <TouchableOpacity style={s.playButton} onPress={() => setPlaying(!playing)}><Text style={{ color: C.bg, fontWeight: "900" }}>{playing ? "Ⅱ" : "▶"}</Text></TouchableOpacity>
    </View>}
    <View style={s.nav}>
      {[["Home","⌂"],["Search","⌕"],["Library","▤"]].map(([name, icon]) =>
        <TouchableOpacity key={name} onPress={() => setTab(name)} style={s.navItem}>
          <Text style={{ color: tab === name ? C.lime : C.muted, fontSize: 21 }}>{icon}</Text>
          <Text style={{ color: tab === name ? C.lime : C.muted, fontSize: 10, fontWeight: "700" }}>{name}</Text>
        </TouchableOpacity>)}
    </View>
    {playing && <View style={s.videoOverlay}>
      <View style={s.videoHeader}>
        <TouchableOpacity onPress={() => setPlaying(false)}><Text style={{ color: C.text, fontSize: 25 }}>⌄</Text></TouchableOpacity>
        <Text style={s.videoHeaderTitle}>NOW PLAYING</Text>
        <Text style={{ color: C.muted }}>⋯</Text>
      </View>
      <View style={s.videoFrame}>
        <WebView
          source={{ html: `<html><body style="margin:0;background:#000"><iframe width="100%" height="100%" src="https://www.youtube-nocookie.com/embed/${current.id}?autoplay=1&playsinline=1" title="YouTube player" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></body></html>` }}
          javaScriptEnabled domStorageEnabled allowsFullscreenVideo
          mediaPlaybackRequiresUserAction={false} style={{ backgroundColor: "#000" }}
        />
      </View>
      <Text style={s.videoTitle}>{current.title}</Text>
      <Text style={s.videoArtist}>{current.artist}</Text>
      <Text style={s.videoNote}>Playback is provided by the official YouTube embedded player.</Text>
      <TouchableOpacity style={s.closeVideo} onPress={() => setPlaying(false)}><Text style={{ color: C.bg, fontWeight: "900" }}>CLOSE PLAYER</Text></TouchableOpacity>
    </View>}
  </SafeAreaView>;
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: { height: 58, flexDirection: "row", alignItems: "center", paddingHorizontal: 20, gap: 10 },
  brandMark: { width: 30, height: 30, borderRadius: 10, backgroundColor: C.lime, alignItems: "center", justifyContent: "center" },
  brand: { color: C.text, fontSize: 20, fontWeight: "900", letterSpacing: -1 },
  avatar: { width: 32, height: 32, borderRadius: 16, backgroundColor: C.panel2, alignItems: "center", justifyContent: "center" },
  content: { paddingHorizontal: 20, paddingBottom: 26 },
  eyebrow: { color: C.purple, fontSize: 9, fontWeight: "900", letterSpacing: 2, marginTop: 12 },
  heading: { color: C.text, fontSize: 31, fontWeight: "900", letterSpacing: -1.2, marginTop: 6, marginBottom: 18 },
  hero: { backgroundColor: "#25223A", borderRadius: 24, padding: 20, minHeight: 190, flexDirection: "row", overflow: "hidden", alignItems: "center" },
  heroTag: { color: C.lime, fontSize: 9, fontWeight: "900", letterSpacing: 1.5 },
  heroTitle: { color: C.text, fontSize: 32, fontWeight: "900", lineHeight: 34, marginTop: 9 },
  heroSub: { color: "#C1BED0", fontSize: 11, marginTop: 8 },
  heroButton: { backgroundColor: C.lime, alignSelf: "flex-start", paddingHorizontal: 14, paddingVertical: 10, borderRadius: 20, marginTop: 15 },
  heroButtonText: { color: C.bg, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  orb: { width: 108, height: 108, borderRadius: 54, backgroundColor: C.purple, alignItems: "center", justifyContent: "center", marginLeft: -8, transform: [{ rotate: "-12deg" }] },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 24, marginBottom: 12 },
  sectionTitle: { color: C.text, fontSize: 18, fontWeight: "800", letterSpacing: -0.4, marginTop: 22, marginBottom: 12 },
  seeAll: { color: C.lime, fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  featureCard: { flexDirection: "row", alignItems: "center", gap: 12, padding: 12, backgroundColor: C.panel, borderRadius: 18, marginTop: 3 },
  featureArt: { width: 64, height: 64, borderRadius: 12 },
  featureLabel: { color: C.purple, fontSize: 8, fontWeight: "900", letterSpacing: 1.2 },
  featureTitle: { color: C.text, fontSize: 15, fontWeight: "800", marginTop: 4, marginBottom: 3 },
  songRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 9 },
  songArt: { width: 50, height: 50, borderRadius: 10, backgroundColor: C.panel2 },
  songTitle: { color: C.text, fontSize: 13, fontWeight: "700" },
  songArtist: { color: C.muted, fontSize: 11, marginTop: 4 },
  likeBtn: { paddingHorizontal: 5 },
  searchBox: { backgroundColor: C.panel, borderRadius: 16, height: 54, paddingHorizontal: 15, flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderColor: C.line },
  searchInput: { flex: 1, color: C.text, fontSize: 13 },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 14 },
  chip: { borderWidth: 1, borderColor: C.line, paddingVertical: 8, paddingHorizontal: 13, borderRadius: 20 },
  chipOn: { backgroundColor: C.lime, borderColor: C.lime },
  chipText: { color: C.muted, fontSize: 10, fontWeight: "700" },
  subheading: { color: C.muted, fontSize: 12, marginBottom: 5 },
  empty: { alignItems: "center", padding: 35, backgroundColor: C.panel, borderRadius: 18 },
  emptyTitle: { color: C.text, fontSize: 15, fontWeight: "800", marginTop: 10, marginBottom: 4 },
  error: { color: "#FF8C9B", fontSize: 11, marginTop: 12 },
  footer: { color: "#555563", fontSize: 8, letterSpacing: 2, textAlign: "center", marginTop: 30, marginBottom: 12 },
  player: { height: 66, backgroundColor: "#20202A", borderTopWidth: 1, borderTopColor: C.line, flexDirection: "row", alignItems: "center", paddingHorizontal: 14, gap: 11 },
  playerArt: { width: 42, height: 42, borderRadius: 8 },
  playerTitle: { color: C.text, fontSize: 12, fontWeight: "800" },
  playerArtist: { color: C.muted, fontSize: 10, marginTop: 3 },
  playButton: { width: 34, height: 34, borderRadius: 17, backgroundColor: C.lime, alignItems: "center", justifyContent: "center", marginLeft: 5 },
  nav: { height: 62, backgroundColor: C.bg, borderTopWidth: 1, borderTopColor: C.line, flexDirection: "row", justifyContent: "space-around", alignItems: "center" },
  navItem: { alignItems: "center", gap: 3, minWidth: 60 },
  videoOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: C.bg, paddingTop: 48, paddingHorizontal: 18 },
  videoHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", height: 42 },
  videoHeaderTitle: { color: C.muted, fontSize: 10, fontWeight: "900", letterSpacing: 2 },
  videoFrame: { height: 230, marginTop: 25, backgroundColor: "#000", borderRadius: 14, overflow: "hidden" },
  videoTitle: { color: C.text, fontSize: 22, fontWeight: "900", marginTop: 24 },
  videoArtist: { color: C.muted, fontSize: 13, marginTop: 6 },
  videoNote: { color: C.muted, fontSize: 10, marginTop: 15, lineHeight: 16 },
  closeVideo: { backgroundColor: C.lime, padding: 15, borderRadius: 24, alignItems: "center", marginTop: 28 }
});