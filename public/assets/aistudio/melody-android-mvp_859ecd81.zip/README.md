# Melody — Android music app MVP

A React Native + Expo starter app with a distinctive dark UI, YouTube music search, favourites, and an official embedded YouTube player.

## Included in this MVP
- Home, Search, and Library tabs
- YouTube Data API video search (music category)
- Official YouTube embedded playback via `react-native-webview`
- Liked songs stored in app state while the app is running
- Featured mix and starter discovery tracks
- Android-ready Expo project structure

## Requirements
- Node.js LTS
- Expo CLI through `npx expo`
- Android Studio / Android emulator, or Expo Go on an Android phone
- A YouTube Data API v3 key from Google Cloud Console

## Run it
1. Extract the ZIP and open this folder in a terminal.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env` and add your YouTube API key:
   ```env
   EXPO_PUBLIC_YOUTUBE_API_KEY=YOUR_KEY
   ```
4. Start Expo:
   ```bash
   npx expo start
   ```
5. Open the project on an Android device or emulator.

## Build an installable Android package
Install EAS CLI and sign in:
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```
The EAS build service produces the Android build artifact. This source ZIP is not itself an APK.

## YouTube integration and policy
Search uses the YouTube Data API v3. Playback uses the official YouTube embedded player in a WebView. The app does not download, extract, or convert YouTube media to MP3. Follow YouTube API Services Terms, Developer Policies, branding requirements, and applicable copyright rules. API keys should be restricted in Google Cloud Console and should not be committed to a public repository.

## Current MVP limitations
- Favourites and playlists are local in-memory state; they reset when the app restarts.
- Authentication, cloud sync, durable playlists, recommendations, and background playback are not implemented.
- YouTube search requires a configured API key and internet access.
- The starter home feed contains sample video IDs; replace them with curated, rights-cleared content or live API results before release.
- Use licensed audio sources if you later add native audio playback outside YouTube's embedded player.
